from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib import messages
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .forms import CustomSignupForm, LoginForm, ProfileUpdateForm
from .models import CustomUser


class LoginView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return redirect('dashboard:home')
        return render(request, 'accounts/login.html', {'form': LoginForm()})

    def post(self, request):
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(request,
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'])
            if user:
                login(request, user)
                messages.success(request, f'Welcome back, {user.username}! 👋')
                return redirect('dashboard:teacher_home' if user.is_teacher else 'dashboard:student_home')
            messages.error(request, '❌ Invalid username or password.')
        return render(request, 'accounts/login.html', {'form': form})


class SignupView(View):
    def get(self, request):
        return render(request, 'accounts/signup.html', {'form': CustomSignupForm()})

    def post(self, request):
        form = CustomSignupForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Account created successfully! Please log in.')
            return redirect('accounts:login')
        return render(request, 'accounts/signup.html', {'form': form})


class LogoutView(View):
    def get(self, request):
        logout(request)
        messages.info(request, 'You have been logged out.')
        return redirect('accounts:login')
    def post(self, request):
        logout(request)
        return redirect('accounts:login')


class ForgotPasswordView(View):
    def get(self, request):
        return render(request, 'accounts/forgot_password.html')

    def post(self, request):
        email    = request.POST.get('email', '').strip()
        new_pw   = request.POST.get('new_password', '').strip()
        confirm  = request.POST.get('confirm_password', '').strip()
        if not email or not new_pw:
            messages.error(request, 'All fields are required.')
            return render(request, 'accounts/forgot_password.html')
        if new_pw != confirm:
            messages.error(request, '❌ Passwords do not match.')
            return render(request, 'accounts/forgot_password.html')
        if len(new_pw) < 6:
            messages.error(request, '❌ Password must be at least 6 characters.')
            return render(request, 'accounts/forgot_password.html')
        try:
            user = CustomUser.objects.get(email=email)
            user.set_password(new_pw)
            user.save()
            messages.success(request, '✅ Password reset! Please log in with your new password.')
            return redirect('accounts:login')
        except CustomUser.DoesNotExist:
            messages.error(request, '❌ No account found with that email address.')
        return render(request, 'accounts/forgot_password.html')


@method_decorator(login_required, name='dispatch')
class ProfileView(View):
    def get(self, request):
        form = ProfileUpdateForm(instance=request.user)
        return render(request, 'accounts/profile.html', {'form': form})

    def post(self, request):
        form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            user = form.save()
            new_pw  = request.POST.get('new_password', '').strip()
            confirm = request.POST.get('confirm_password', '').strip()
            if new_pw:
                if new_pw != confirm:
                    messages.error(request, '❌ Passwords do not match.')
                    return render(request, 'accounts/profile.html', {'form': form})
                if len(new_pw) < 6:
                    messages.error(request, '❌ Password must be at least 6 characters.')
                    return render(request, 'accounts/profile.html', {'form': form})
                user.set_password(new_pw)
                user.save()
                update_session_auth_hash(request, user)
            messages.success(request, '✅ Profile updated successfully!')
            return redirect('accounts:profile')
        return render(request, 'accounts/profile.html', {'form': form})
