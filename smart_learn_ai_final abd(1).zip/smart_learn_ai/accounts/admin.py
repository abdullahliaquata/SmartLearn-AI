from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'is_teacher', 'is_student', 'date_joined']
    list_filter = ['is_teacher', 'is_student']
    fieldsets = UserAdmin.fieldsets + (
        ('Role', {'fields': ('is_teacher', 'is_student', 'bio', 'profile_picture')}),
    )
