"""
Run this script to create demo users and data:
  python manage.py shell < setup_demo.py
"""
import django, os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartlearn_project.settings')
django.setup()

from accounts.models import CustomUser
from courses.models import Course
from assignments.models import Assignment
from ai_tools.models import Quiz, QuizResult
from analytics.models import Recommendation

def run():
    if not CustomUser.objects.filter(username='admin').exists():
        CustomUser.objects.create_superuser('admin', 'admin@smartlearn.ai', 'admin123')
        print("✅ Superuser: admin / admin123")

    teacher, _ = CustomUser.objects.get_or_create(username='teacher1', defaults={
        'email': 'teacher@smartlearn.ai', 'is_teacher': True})
    teacher.set_password('teacher123')
    teacher.save()
    print("✅ Teacher: teacher1 / teacher123")

    student, _ = CustomUser.objects.get_or_create(username='student1', defaults={
        'email': 'student@smartlearn.ai', 'is_student': True, 'day_streak': 7})
    student.set_password('student123')
    student.save()
    print("✅ Student: student1 / student123")

    for title, desc, code, color in [
        ('Machine Learning Fundamentals', 'Learn ML algorithms and neural networks.', 'ML101', '#6c63ff'),
        ('Python Programming', 'Master Python from basics to advanced.', 'PY202', '#4d8af0'),
        ('Data Structures & Algorithms', 'Arrays, trees, graphs, sorting.', 'DSA303', '#10b981'),
    ]:
        c, created = Course.objects.get_or_create(course_code=code, defaults={
            'title': title, 'description': desc, 'teacher': teacher, 'color': color})
        c.students.add(student)
        if created: print(f"✅ Course: {title} ({code})")

    ml = Course.objects.get(course_code='ML101')
    if not Assignment.objects.filter(submitted_by=student, course=ml).exists():
        Assignment.objects.create(course=ml, title='Lab 1: Linear Regression',
            description='Implement from scratch.', submitted_by=student,
            grade=88, feedback='Excellent work!', status='graded')
        print("✅ Demo assignment created")

    q = Quiz.objects.create(user=student, topic='Machine Learning', questions_data=[], difficulty='medium')
    if not QuizResult.objects.filter(user=student).exists():
        QuizResult.objects.create(user=student, quiz=q, score=4, total=5, topic='Machine Learning')
        QuizResult.objects.create(user=student, quiz=q, score=3, total=5, topic='Python')
        print("✅ Demo quiz results created")

    print("\n🎉 Demo data ready! Run: python manage.py runserver")

run()
