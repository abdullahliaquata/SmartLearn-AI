from django import forms
from .models import Assignment
from courses.models import Course


class AssignmentForm(forms.ModelForm):
    class Meta:
        model  = Assignment
        fields = ['course', 'title', 'description', 'file']
        widgets = {
            'title':       forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Assignment title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'course':      forms.Select(attrs={'class': 'form-select'}),
            'file':        forms.FileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['course'].queryset = Course.objects.filter(students=user)
        self.fields['file'].required = False


class GradeForm(forms.ModelForm):
    class Meta:
        model  = Assignment
        fields = ['grade', 'feedback']
        widgets = {
            'grade':    forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 100}),
            'feedback': forms.Textarea(attrs={'class': 'form-control', 'rows': 4,
                                              'placeholder': 'Provide constructive feedback...'}),
        }
