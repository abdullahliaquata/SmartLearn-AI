from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.utils.decorators import method_decorator
from django.views import View
from .models import Assignment, Notification
from .forms import AssignmentForm, GradeForm
from courses.models import Course

is_teacher = lambda u: u.is_teacher
is_student  = lambda u: u.is_student


@method_decorator([login_required, user_passes_test(is_student)], name='dispatch')
class UploadAssignmentView(View):
    def get(self, request):
        form = AssignmentForm(user=request.user)
        return render(request, 'assignments/upload.html', {'form': form})

    def post(self, request):
        form = AssignmentForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            assignment = form.save(commit=False)
            assignment.submitted_by = request.user
            assignment.save()
            messages.success(request, '✅ Assignment submitted successfully!')
            return redirect('dashboard:student_home')
        messages.error(request, '❌ Please fix the errors below.')
        return render(request, 'assignments/upload.html', {'form': form})


@method_decorator([login_required, user_passes_test(is_student)], name='dispatch')
class EditAssignmentView(View):
    def get(self, request, pk):
        assignment = get_object_or_404(Assignment, pk=pk, submitted_by=request.user, status='pending')
        form = AssignmentForm(instance=assignment, user=request.user)
        return render(request, 'assignments/edit_assignment.html',
                      {'form': form, 'assignment': assignment})

    def post(self, request, pk):
        assignment = get_object_or_404(Assignment, pk=pk, submitted_by=request.user, status='pending')
        form = AssignmentForm(request.POST, request.FILES, instance=assignment, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Assignment updated successfully!')
            return redirect('assignments:mine')
        return render(request, 'assignments/edit_assignment.html',
                      {'form': form, 'assignment': assignment})


@login_required
@user_passes_test(is_student)
def delete_assignment(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk, submitted_by=request.user, status='pending')
    title = assignment.title
    assignment.delete()
    messages.success(request, f'✅ Assignment "{title}" deleted.')
    return redirect('assignments:mine')


@login_required
@user_passes_test(is_teacher)
def teacher_assignments(request):
    my_courses  = Course.objects.filter(teacher=request.user)
    assignments = Assignment.objects.filter(course__in=my_courses).order_by('-submitted_at')
    pending     = assignments.filter(status='pending').count()
    return render(request, 'assignments/teacher_assignments.html',
                  {'assignments': assignments, 'pending': pending})


@login_required
@user_passes_test(is_teacher)
def grade_assignment(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk, course__teacher=request.user)
    if request.method == 'POST':
        form = GradeForm(request.POST, instance=assignment)
        if form.is_valid():
            a = form.save(commit=False)
            a.status = 'graded'
            a.save()
            Notification.objects.create(
                user=assignment.submitted_by,
                message=f'🎉 Your assignment "{assignment.title}" was graded! Score: {a.grade}/100')
            messages.success(request, f'✅ Assignment graded: {a.grade}/100')
            return redirect('assignments:teacher_list')
    else:
        form = GradeForm(instance=assignment)
    return render(request, 'assignments/grade.html', {'assignment': assignment, 'form': form})


@login_required
def my_assignments(request):
    assignments = Assignment.objects.filter(submitted_by=request.user).order_by('-submitted_at')
    return render(request, 'assignments/my_assignments.html', {'assignments': assignments})
