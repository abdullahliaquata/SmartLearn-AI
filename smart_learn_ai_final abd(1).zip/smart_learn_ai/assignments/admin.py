from django.contrib import admin
from .models import Assignment, Notification

@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = ['title', 'submitted_by', 'course', 'status', 'grade', 'submitted_at']
    list_filter = ['status', 'course']

admin.site.register(Notification)
