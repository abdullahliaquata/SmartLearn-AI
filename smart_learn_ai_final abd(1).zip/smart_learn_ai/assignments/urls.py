from django.urls import path
from . import views

app_name = 'assignments'

urlpatterns = [
    path('upload/',              views.UploadAssignmentView.as_view(), name='upload'),
    path('<int:pk>/edit/',       views.EditAssignmentView.as_view(),   name='edit'),
    path('<int:pk>/delete/',     views.delete_assignment,              name='delete'),
    path('teacher/',             views.teacher_assignments,            name='teacher_list'),
    path('grade/<int:pk>/',      views.grade_assignment,               name='grade'),
    path('mine/',                views.my_assignments,                 name='mine'),
]
