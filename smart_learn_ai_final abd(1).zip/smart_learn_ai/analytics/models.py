from django.db import models
from django.conf import settings

class AttentionLog(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='attention_logs')
    session_id = models.CharField(max_length=100, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    attention_score = models.IntegerField(default=100)
    is_distracted = models.BooleanField(default=False)
    duration_minutes = models.FloatField(default=0)

    def __str__(self):
        return f"{self.user.username} - {self.attention_score}% - {self.timestamp}"

class PerformanceMetric(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='performance_metrics')
    date = models.DateField(auto_now_add=True)
    avg_quiz_score = models.FloatField(default=0)
    assignments_submitted = models.IntegerField(default=0)
    avg_attention = models.FloatField(default=0)

class Recommendation(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='recommendations')
    topic = models.CharField(max_length=200)
    message = models.TextField()
    resource_link = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} - {self.topic}"
