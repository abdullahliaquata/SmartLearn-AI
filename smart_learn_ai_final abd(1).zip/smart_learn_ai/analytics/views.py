from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse
from ai_tools.models import QuizResult
from analytics.models import AttentionLog, Recommendation
from assignments.models import Assignment
from courses.models import Course
from collections import Counter
import json

@login_required
def student_analytics(request):
    user = request.user
    quiz_results = QuizResult.objects.filter(user=user).order_by('taken_at')
    attention_logs = AttentionLog.objects.filter(user=user).order_by('timestamp')
    assignments = Assignment.objects.filter(submitted_by=user, status='graded')

    # Quiz data for chart
    quiz_dates = [q.taken_at.strftime('%b %d') for q in quiz_results]
    quiz_scores = [q.percentage for q in quiz_results]

    # Attention data
    attention_dates = [a.timestamp.strftime('%b %d %H:%M') for a in attention_logs[:10]]
    attention_scores = [a.attention_score for a in attention_logs[:10]]

    # Assignment scores
    assignment_scores = [(a.title[:15], a.grade) for a in assignments]

    # Weak topics from wrong quiz answers
    topics = [q.topic for q in quiz_results if q.percentage < 60]
    weak_topics = Counter(topics).most_common(3)

    # Averages
    avg_quiz = round(sum(quiz_scores)/len(quiz_scores), 1) if quiz_scores else 0
    avg_attention = round(sum(attention_scores)/len(attention_scores), 1) if attention_scores else 0
    avg_assignment = round(sum(a.grade for a in assignments if a.grade)/max(assignments.count(), 1), 1)

    # Generate recommendations for weak topics
    for topic, count in weak_topics:
        if not Recommendation.objects.filter(user=user, topic=topic).exists():
            Recommendation.objects.create(
                user=user,
                topic=topic,
                message=f'You scored below 60% in {topic} quizzes. Review the core concepts.',
                resource_link=f'https://www.youtube.com/results?search_query={topic.replace(" ", "+")}'
            )

    recommendations = Recommendation.objects.filter(user=user).order_by('-created_at')[:5]

    context = {
        'quiz_dates': json.dumps(quiz_dates),
        'quiz_scores': json.dumps(quiz_scores),
        'attention_dates': json.dumps(attention_dates),
        'attention_scores': json.dumps(attention_scores),
        'weak_topics': weak_topics,
        'avg_quiz': avg_quiz,
        'avg_attention': avg_attention,
        'avg_assignment': avg_assignment,
        'recommendations': recommendations,
        'quiz_count': quiz_results.count(),
        'assignments_graded': assignments.count(),
        'assignment_scores': assignment_scores,
    }
    return render(request, 'analytics/student_analytics.html', context)

@login_required
@user_passes_test(lambda u: u.is_teacher)
def teacher_analytics(request):
    my_courses = Course.objects.filter(teacher=request.user)
    all_assignments = Assignment.objects.filter(course__in=my_courses)
    graded = all_assignments.filter(status='graded')

    # Per-course stats
    course_stats = []
    for course in my_courses:
        c_assignments = graded.filter(course=course)
        avg = 0
        if c_assignments.exists():
            avg = round(sum(a.grade for a in c_assignments if a.grade)/c_assignments.count(), 1)
        course_stats.append({'course': course, 'avg': avg, 'count': c_assignments.count()})

    # Student rankings
    student_grades = {}
    for a in graded:
        u = a.submitted_by
        if u not in student_grades:
            student_grades[u] = []
        if a.grade:
            student_grades[u].append(a.grade)

    rankings = []
    for user, grades in student_grades.items():
        avg = round(sum(grades)/len(grades), 1) if grades else 0
        rankings.append({'user': user, 'avg': avg, 'count': len(grades)})
    rankings.sort(key=lambda x: x['avg'], reverse=True)

    context = {
        'course_stats': course_stats,
        'rankings': rankings[:10],
        'total_students': sum(c.student_count() for c in my_courses),
        'pending_count': all_assignments.filter(status='pending').count(),
        'graded_count': graded.count(),
        'course_names': json.dumps([c.title[:15] for c in my_courses]),
        'course_avgs': json.dumps([s['avg'] for s in course_stats]),
    }
    return render(request, 'analytics/teacher_analytics.html', context)
