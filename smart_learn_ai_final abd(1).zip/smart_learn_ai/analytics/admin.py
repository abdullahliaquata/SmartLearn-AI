from django.contrib import admin
from .models import AttentionLog, PerformanceMetric, Recommendation

admin.site.register(AttentionLog)
admin.site.register(PerformanceMetric)
admin.site.register(Recommendation)
