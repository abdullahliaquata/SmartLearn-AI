from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('',         views.home,         name='home'),
    path('student/', views.student_home, name='student_home'),
    path('teacher/', views.teacher_home, name='teacher_home'),
]
