from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from courses.models import Course
from assignments.models import Assignment, Notification
from ai_tools.models import QuizResult
from analytics.models import AttentionLog, Recommendation


@login_required
def home(request):
    return redirect('dashboard:teacher_home' if request.user.is_teacher else 'dashboard:student_home')


@login_required
def student_home(request):
    if not request.user.is_student:
        return redirect('dashboard:teacher_home')

    enrolled    = request.user.enrolled_courses.all()
    results     = QuizResult.objects.filter(user=request.user).order_by('-taken_at')
    assignments = Assignment.objects.filter(submitted_by=request.user)
    notifs      = Notification.objects.filter(user=request.user, is_read=False).order_by('-created_at')[:5]
    recs        = Recommendation.objects.filter(user=request.user).order_by('-created_at')[:3]
    logs        = AttentionLog.objects.filter(user=request.user).order_by('-timestamp')[:10]

    graded = assignments.filter(status='graded')
    vals   = [a.grade for a in graded if a.grade is not None]
    avg_score = round(sum(vals)/len(vals), 1) if vals else 0
    quiz_avg  = round(sum(q.percentage for q in results)/results.count(), 1) if results.exists() else 0
    avg_att   = round(sum(l.attention_score for l in logs)/logs.count(), 1) if logs.exists() else 0

    stat_items = [
        (f'{avg_score}%',                   'Avg Assignment Score', '#6c63ff', '#ede9ff', '📊'),
        (enrolled.count(),                  'Enrolled Courses',     '#4d8af0', '#e0ecff', '📚'),
        (results.count(),                   'Quizzes Taken',        '#10b981', '#d1fae5', '📝'),
        (f'{request.user.day_streak}🔥',    'Day Streak',           '#f59e0b', '#fef3c7', '⚡'),
    ]
    ai_tools_list = [
        ('ai_tools:chatbot',   '🤖', 'AI Chatbot Tutor',  'Ask any question',    'linear-gradient(135deg,#6c63ff,#4d8af0)'),
        ('ai_tools:quiz',      '📝', 'AI Quiz Generator', 'Test your knowledge', 'linear-gradient(135deg,#10b981,#059669)'),
        ('ai_tools:attention', '👁️', 'Attention Tracker', 'Stay focused',        'linear-gradient(135deg,#f59e0b,#d97706)'),
        ('analytics:student',  '📊', 'My Analytics',      'View performance',    'linear-gradient(135deg,#ef4444,#dc2626)'),
    ]
    return render(request, 'dashboard/student_dashboard.html', {
        'enrolled_courses': enrolled,
        'quiz_results':     list(results[:5]),
        'notifications':    notifs,
        'recommendations':  recs,
        'avg_score':    avg_score,
        'quiz_avg':     quiz_avg,
        'avg_attention':avg_att,
        'courses_count':enrolled.count(),
        'quizzes_count':results.count(),
        'day_streak':   request.user.day_streak,
        'assignments':  assignments,
        'stat_items':   stat_items,
        'ai_tools':     ai_tools_list,
    })


@login_required
def teacher_home(request):
    if not request.user.is_teacher:
        return redirect('dashboard:student_home')

    my_courses = Course.objects.filter(teacher=request.user)
    all_assign = Assignment.objects.filter(course__in=my_courses)
    pending    = all_assign.filter(status='pending')
    graded     = all_assign.filter(status='graded')
    total_stu  = sum(c.student_count() for c in my_courses)
    vals       = [a.grade for a in graded if a.grade is not None]
    class_avg  = round(sum(vals)/len(vals), 1) if vals else 0

    stats = [
        (my_courses.count(),  'Total Courses',   '#6c63ff', '#ede9ff', '📚'),
        (total_stu,           'Total Students',  '#4d8af0', '#e0ecff', '👥'),
        (pending.count(),     'Pending Grades',  '#ef4444', '#fee2e2', '⏳'),
        (f'{class_avg}%',     'Class Average',   '#10b981', '#d1fae5', '📈'),
    ]
    quick_actions = [
        ('courses:create',          '➕', 'Create New Course',    '#6c63ff', '#f8f7ff'),
        ('assignments:teacher_list','📋', 'View All Assignments', '#4d8af0', '#f0f8ff'),
        ('analytics:teacher',       '📊', 'Class Analytics',      '#10b981', '#f0fdf4'),
        ('ai_tools:chatbot',        '🤖', 'AI Chatbot Tutor',     '#f59e0b', '#fffbeb'),
    ]
    return render(request, 'dashboard/teacher_dashboard.html', {
        'my_courses':          my_courses,
        'pending_assignments': pending,
        'pending_count':       pending.count(),
        'total_students':      total_stu,
        'class_avg':           class_avg,
        'recent_submissions':  all_assign.order_by('-submitted_at')[:5],
        'courses_count':       my_courses.count(),
        'stats':               stats,
        'quick_actions':       quick_actions,
    })
