import json, re, uuid, base64, io
import urllib.request, urllib.error
from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.conf import settings as django_settings
from .models import Quiz, QuizResult, ChatMessage
from analytics.models import AttentionLog

OLLAMA_URL   = getattr(django_settings, 'OLLAMA_BASE_URL', 'http://localhost:11434')
OLLAMA_MODEL = getattr(django_settings, 'OLLAMA_MODEL',    'llama3.2')


# ─── Ollama helpers ────────────────────────────────────────
def call_ollama_chat(messages):
    try:
        payload = json.dumps({'model': OLLAMA_MODEL, 'messages': messages, 'stream': False}).encode()
        req = urllib.request.Request(f'{OLLAMA_URL}/api/chat', data=payload,
                                     headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.loads(r.read())['message']['content'], None
    except urllib.error.URLError:
        return None, 'offline'
    except Exception as e:
        return None, str(e)


def call_ollama_generate(prompt):
    try:
        payload = json.dumps({'model': OLLAMA_MODEL, 'prompt': prompt, 'stream': False}).encode()
        req = urllib.request.Request(f'{OLLAMA_URL}/api/generate', data=payload,
                                     headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.loads(r.read()).get('response', '')
    except Exception:
        return None


def offline_msg():
    return (
        "⚠️ **Ollama is not reachable.**\n\n"
        "To fix this, open a terminal and run:\n"
        "```\nollama serve\n```\n"
        "Then pull the model if you haven't already:\n"
        "```\nollama pull llama3.2\n```\n\n"
        "Once Ollama is running, resend your message — the AI will respond instantly! 🚀"
    )


def get_demo_questions(topic):
    return [
        {"question": f"What is the primary purpose of {topic}?",
         "options": ["Theoretical study only","Solving real-world problems","Entertainment","None of the above"],
         "correct": 1, "explanation": f"{topic} is primarily used to solve real-world problems."},
        {"question": f"Which approach is best when learning {topic}?",
         "options": ["Memorisation only","Practice and application","Skipping hard parts","Only watching videos"],
         "correct": 1, "explanation": "Hands-on practice leads to deeper understanding."},
        {"question": f"A key skill needed for {topic} is:",
         "options": ["Creative writing","Logical thinking","Physical fitness","Cooking"],
         "correct": 1, "explanation": "Logical thinking is fundamental."},
        {"question": f"When stuck on a {topic} problem, you should:",
         "options": ["Give up","Break it into smaller parts","Copy others","Ignore it"],
         "correct": 1, "explanation": "Breaking problems into smaller parts is essential."},
        {"question": f"The best way to test your {topic} knowledge is:",
         "options": ["Re-read once","Build a project or take a quiz","Watch a documentary","Sleep on it"],
         "correct": 1, "explanation": "Active recall solidifies knowledge."},
    ]


# ─── Chatbot ───────────────────────────────────────────────
@login_required
def chatbot(request):
    sk = request.session.session_key or ''
    if not sk:
        request.session.create()
        sk = request.session.session_key
    history = ChatMessage.objects.filter(user=request.user, session_key=sk).order_by('timestamp')[:40]
    return render(request, 'ai_tools/chatbot.html', {'history': history})


@login_required
@require_POST
def chat_api(request):
    """Handle text messages AND file/image uploads."""
    # ── detect multipart (file upload) vs JSON ──
    is_multipart = request.content_type and 'multipart' in request.content_type

    if is_multipart:
        user_message = request.POST.get('message', '').strip()
        uploaded     = request.FILES.get('attachment')
    else:
        try:
            body         = json.loads(request.body)
            user_message = body.get('message', '').strip()
            uploaded     = None
        except Exception:
            return JsonResponse({'error': 'Bad request'}, status=400)

    if not user_message and not uploaded:
        return JsonResponse({'error': 'Empty message'}, status=400)

    sk = request.session.session_key or ''

    # ── Build display text & AI prompt ──
    display_text  = user_message
    file_context  = ''
    file_info_msg = ''

    if uploaded:
        fname = uploaded.name
        ftype = uploaded.content_type or ''
        fsize = uploaded.size

        if ftype.startswith('image/'):
            # Read image → base64 for display hint; ask AI to describe
            img_data    = base64.b64encode(uploaded.read()).decode()
            file_context = (
                f'\n\n[User attached an image: {fname} ({fsize//1024}KB)]\n'
                f'Please analyse this image and respond to the user\'s request: "{user_message or "Describe this image and provide a detailed summary."}"'
            )
            file_info_msg = f'📎 Image: **{fname}**'

        elif ftype == 'application/pdf' or fname.endswith('.pdf'):
            # Extract text from PDF if possible
            try:
                import io as _io
                raw = uploaded.read()
                try:
                    import PyPDF2
                    reader = PyPDF2.PdfReader(_io.BytesIO(raw))
                    pdf_text = '\n'.join(p.extract_text() or '' for p in reader.pages)
                    pdf_text = pdf_text[:3000]
                except Exception:
                    pdf_text = f'[PDF file: {fname}, could not extract text]'
                file_context = (
                    f'\n\n[User attached PDF: {fname}]\nContent preview:\n{pdf_text}\n\n'
                    f'User request: "{user_message or "Please summarise this PDF document."}"'
                )
            except Exception:
                file_context = f'\n\n[User attached PDF: {fname}. Respond to: "{user_message}"]'
            file_info_msg = f'📄 PDF: **{fname}**'

        else:
            # Plain text / code file
            try:
                text_content = uploaded.read().decode('utf-8', errors='replace')[:3000]
                file_context = (
                    f'\n\n[User attached file: {fname}]\nContent:\n```\n{text_content}\n```\n'
                    f'User request: "{user_message or "Please summarise or analyse this file."}"'
                )
            except Exception:
                file_context = f'\n\n[User attached: {fname}. Respond to: "{user_message}"]'
            file_info_msg = f'📁 File: **{fname}**'

        display_text = (f'{user_message}\n{file_info_msg}' if user_message else file_info_msg).strip()

    # ── Save user message ──
    ChatMessage.objects.create(user=request.user, role='user', content=display_text, session_key=sk)

    # ── Build Ollama context ──
    history_qs = ChatMessage.objects.filter(user=request.user, session_key=sk).order_by('timestamp')[:14]
    ollama_msgs = [{
        'role': 'system',
        'content': (
            f'You are SMART LEARN AI, an intelligent academic tutor. '
            f'You help students understand concepts, summarise documents, '
            f'generate quiz questions, analyse images, and explain code. '
            f"Student name: {request.user.username}. "
            f'Be concise, clear, educational, and encouraging. '
            f'When summarising files or PDFs, structure your response with headings and bullet points.'
        ),
    }]
    for m in history_qs:
        ollama_msgs.append({'role': m.role, 'content': m.content})

    # Append file context to last user message
    if file_context and ollama_msgs[-1]['role'] == 'user':
        ollama_msgs[-1]['content'] += file_context

    answer, err = call_ollama_chat(ollama_msgs)
    if err:
        answer = offline_msg()

    ChatMessage.objects.create(user=request.user, role='assistant', content=answer, session_key=sk)
    return JsonResponse({'answer': answer})


@login_required
def clear_chat(request):
    sk = request.session.session_key or ''
    ChatMessage.objects.filter(user=request.user, session_key=sk).delete()
    return redirect('ai_tools:chatbot')


# ─── Export chat as PDF ────────────────────────────────────
@login_required
def export_chat_pdf(request):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
        from reportlab.lib.enums import TA_LEFT, TA_RIGHT

        sk       = request.session.session_key or ''
        messages_qs = ChatMessage.objects.filter(user=request.user, session_key=sk).order_by('timestamp')

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4,
                                leftMargin=2*cm, rightMargin=2*cm,
                                topMargin=2*cm, bottomMargin=2*cm)

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                     textColor=colors.HexColor('#6c63ff'),
                                     fontSize=18, spaceAfter=6)
        sub_style   = ParagraphStyle('Sub', parent=styles['Normal'],
                                     textColor=colors.gray, fontSize=10, spaceAfter=14)
        user_style  = ParagraphStyle('User', parent=styles['Normal'],
                                     backColor=colors.HexColor('#ede9ff'),
                                     textColor=colors.HexColor('#1f2937'),
                                     fontSize=11, leading=16,
                                     leftIndent=10, rightIndent=10,
                                     spaceBefore=4, spaceAfter=4,
                                     borderPadding=(6, 8, 6, 8))
        ai_style    = ParagraphStyle('AI', parent=styles['Normal'],
                                     backColor=colors.HexColor('#f8f7ff'),
                                     textColor=colors.HexColor('#374151'),
                                     fontSize=11, leading=16,
                                     leftIndent=10, rightIndent=10,
                                     spaceBefore=4, spaceAfter=4,
                                     borderPadding=(6, 8, 6, 8))

        story = [
            Paragraph('🧠 SMART LEARN AI', title_style),
            Paragraph(f'Chat Export — {request.user.username} — {__import__("datetime").date.today()}', sub_style),
            HRFlowable(width='100%', thickness=1, color=colors.HexColor('#e8ecf0')),
            Spacer(1, 0.4*cm),
        ]

        for msg in messages_qs:
            label = f'<b>You</b> · {msg.timestamp.strftime("%H:%M")}' if msg.role == 'user' \
                    else f'<b>AI Tutor</b> · {msg.timestamp.strftime("%H:%M")}'
            # sanitise content
            content = msg.content.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
            style   = user_style if msg.role == 'user' else ai_style
            story.append(Paragraph(label, ParagraphStyle('Lbl', parent=styles['Normal'],
                                                          fontSize=9, textColor=colors.gray,
                                                          spaceAfter=2)))
            story.append(Paragraph(content, style))
            story.append(Spacer(1, 0.25*cm))

        doc.build(story)
        buf.seek(0)
        response = HttpResponse(buf, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="smartlearn_chat_{request.user.username}.pdf"'
        return response

    except ImportError:
        from django.contrib import messages as djmsg
        djmsg.error(request, '❌ PDF export requires reportlab: pip install reportlab')
        return redirect('ai_tools:chatbot')


# ─── AI Quiz ───────────────────────────────────────────────
@login_required
def ai_quiz(request):
    return render(request, 'ai_tools/quiz.html')


@login_required
@require_POST
def generate_quiz(request):
    try:
        body       = json.loads(request.body)
        topic      = body.get('topic', 'General Knowledge').strip() or 'General Knowledge'
        difficulty = body.get('difficulty', 'medium')
    except Exception:
        topic, difficulty = 'General Knowledge', 'medium'

    prompt = (
        f'Generate exactly 5 multiple-choice questions about "{topic}" '
        f'at {difficulty} difficulty for university students.\n'
        f'Return ONLY a valid JSON array, no markdown:\n'
        f'[{{"question":"...","options":["A","B","C","D"],"correct":0,"explanation":"..."}}]'
    )
    raw       = call_ollama_generate(prompt)
    questions = None
    if raw:
        try:
            m = re.search(r'\[.*?\]', raw, re.DOTALL)
            if m:
                questions = json.loads(m.group())
                if not (isinstance(questions, list) and len(questions)):
                    questions = None
        except Exception:
            questions = None

    if not questions:
        questions = get_demo_questions(topic)

    quiz = Quiz.objects.create(user=request.user, topic=topic,
                               questions_data=questions, difficulty=difficulty)
    return JsonResponse({'quiz_id': quiz.id, 'questions': questions, 'topic': topic})


@login_required
@require_POST
def submit_quiz(request):
    try:
        body    = json.loads(request.body)
        quiz_id = body.get('quiz_id')
        answers = body.get('answers', {})
    except Exception:
        return JsonResponse({'error': 'Invalid data'}, status=400)
    quiz  = get_object_or_404_local(Quiz, quiz_id, request.user)
    score = 0
    total = len(quiz.questions_data)
    results = []
    for i, q in enumerate(quiz.questions_data):
        ua = answers.get(str(i), -1)
        ca = int(q.get('correct', -1))
        ok = int(ua) == ca
        if ok: score += 1
        results.append({'question': q['question'], 'user_answer': ua,
                        'correct_answer': ca, 'is_correct': ok,
                        'explanation': q.get('explanation', '')})
    QuizResult.objects.create(user=request.user, quiz=quiz, score=score,
                              total=total, answers=answers, topic=quiz.topic)
    pct = round((score/total)*100, 1) if total else 0
    return JsonResponse({'score': score, 'total': total, 'percentage': pct, 'results': results})


def get_object_or_404_local(model, pk, user):
    from django.shortcuts import get_object_or_404
    return get_object_or_404(model, id=pk, user=user)


# ─── Attention Tracker ─────────────────────────────────────
@login_required
def attention_tracker(request):
    logs = AttentionLog.objects.filter(user=request.user).order_by('-timestamp')[:10]
    avg  = round(sum(l.attention_score for l in logs)/len(logs), 1) if logs else 0
    return render(request, 'ai_tools/attention.html', {'logs': logs, 'avg_attention': avg})


@login_required
@require_POST
def log_attention(request):
    try:
        body = json.loads(request.body)
        AttentionLog.objects.create(
            user=request.user,
            session_id=body.get('session_id', str(uuid.uuid4())),
            attention_score=int(body.get('score', 100)),
            is_distracted=bool(body.get('distracted', False)),
            duration_minutes=float(body.get('duration', 0)),
        )
        return JsonResponse({'status': 'ok'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'detail': str(e)}, status=400)
