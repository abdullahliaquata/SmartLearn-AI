from django.db import models
from django.conf import settings

class Quiz(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='quizzes')
    topic = models.CharField(max_length=200)
    questions_data = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
    difficulty = models.CharField(max_length=20, default='medium', choices=[
        ('easy', 'Easy'), ('medium', 'Medium'), ('hard', 'Hard')
    ])

    def __str__(self):
        return f"{self.topic} - {self.user.username}"

class QuizResult(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='quiz_results')
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name='results')
    score = models.IntegerField(default=0)
    total = models.IntegerField(default=0)
    answers = models.JSONField(default=dict)
    taken_at = models.DateTimeField(auto_now_add=True)
    topic = models.CharField(max_length=200, blank=True)

    @property
    def percentage(self):
        if self.total == 0:
            return 0
        return round((self.score / self.total) * 100, 1)

class ChatMessage(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='chat_messages')
    role = models.CharField(max_length=20, choices=[('user', 'User'), ('assistant', 'Assistant')])
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    session_key = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"{self.role}: {self.content[:50]}"
