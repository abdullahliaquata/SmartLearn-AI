from django.urls import path
from . import views

app_name = 'ai_tools'

urlpatterns = [
    path('chatbot/',          views.chatbot,           name='chatbot'),
    path('chat/api/',         views.chat_api,          name='chat_api'),
    path('chat/clear/',       views.clear_chat,        name='clear_chat'),
    path('chat/export-pdf/',  views.export_chat_pdf,   name='export_pdf'),
    path('quiz/',             views.ai_quiz,           name='quiz'),
    path('quiz/generate/',    views.generate_quiz,     name='generate_quiz'),
    path('quiz/submit/',      views.submit_quiz,       name='submit_quiz'),
    path('attention/',        views.attention_tracker, name='attention'),
    path('attention/log/',    views.log_attention,     name='log_attention'),
]
