# 🧠 SMART LEARN AI
### An Intelligent Adaptive Learning Platform
**Final Year Project | Django + Ollama + MediaPipe**

---

## 🚀 QUICK START

### 1. Setup Virtual Environment
```bash
cd smart_learn_ai
python -m venv venv

# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Apply Migrations
```bash
python manage.py migrate
```

### 4. Load Demo Data (already done — skip if db.sqlite3 exists)
```bash
python manage.py shell < setup_demo.py
```

### 5. Install & Start Ollama (for AI Chatbot)
```bash
# Download from: https://ollama.com/download
ollama pull llama3.2
ollama serve
```

### 6. Run Server
```bash
python manage.py runserver
```

Open: **http://127.0.0.1:8000**

---

## 👤 DEMO LOGIN CREDENTIALS

| Role    | Username  | Password    |
|---------|-----------|-------------|
| Teacher | teacher1  | teacher123  |
| Student | student1  | student123  |
| Admin   | admin     | admin123    |

Admin panel: http://127.0.0.1:8000/admin/

---

## 🧩 FEATURES

### ✅ Authentication
- Role-based signup (Teacher / Student)
- Beautiful gradient login page
- Auto-redirect based on role

### ✅ Course Management
- Teacher creates courses with unique codes
- Students enroll via 6-digit course code
- Full course detail pages

### ✅ Assignment Flow
- Students upload files (PDF, DOC, ZIP, images)
- Teacher sees all submissions per course
- Grade (0–100) + feedback with visual grade indicator
- Student gets notification when graded

### ✅ AI Chatbot Tutor (Ollama)
- ChatGPT-style interface
- Uses local Ollama (llama3.2) — NO API key needed
- Full conversation history per session
- Supports concept explanation, summarization, quiz help
- Typing indicator animation

### ✅ AI Quiz Generator
- Enter any topic → AI generates 5 MCQs
- 30-second timer per question
- Difficulty levels: Easy / Medium / Hard
- Detailed answer review with explanations
- Scores saved to analytics

### ✅ Attention Tracker (Computer Vision)
- MediaPipe Face Mesh via webcam
- Eye Aspect Ratio (EAR) for drowsiness detection
- Head pose estimation
- Real-time attention score (0–100%)
- Distraction alerts after 30 frames
- Session logs saved to database

### ✅ Analytics Dashboard
- Quiz score trends (Chart.js line chart)
- Attention history (bar chart)
- Weak topic detection (frequency analysis)
- K-Means clustering classification
- AI-generated recommendations with YouTube links
- Teacher: class averages + student rankings

### ✅ UI/UX
- Purple (#6c63ff) + Blue (#4d8af0) theme
- Dark / Light mode toggle
- Fully responsive
- Smooth animations
- White fixed sidebar with icons

---

## 🏗️ ARCHITECTURE

```
smart_learn_ai/
├── smartlearn_project/     # Django project config
│   ├── settings.py
│   └── urls.py
├── accounts/               # Auth: CustomUser, login, signup
├── courses/                # Course CRUD + enrollment
├── assignments/            # Submit + grade assignments
├── ai_tools/               # Chatbot, Quiz, Attention tracker
├── analytics/              # Charts, recommendations
├── dashboard/              # Student + Teacher dashboards
├── templates/              # All HTML templates
├── static/                 # CSS, JS, images
├── media/                  # Uploaded files
├── db.sqlite3              # SQLite database
└── requirements.txt
```

---

## 🤖 AI MODULES

| Module | Technology | Purpose |
|--------|-----------|---------|
| NLP | Ollama (llama3.2) | Chatbot tutor, quiz generation |
| Computer Vision | MediaPipe Face Mesh | Attention tracking via webcam |
| Data Mining | scikit-learn, Counter | Weak topic detection, clustering |
| Adaptive Learning | Dynamic difficulty | Quiz adjusts to performance |
| Recommendation | Frequency analysis | Personalized study suggestions |

---

## ⚙️ OLLAMA SETUP

1. Download Ollama: https://ollama.com/download
2. Open terminal and run:
```bash
ollama pull llama3.2
ollama serve
```
3. Keep terminal open while using the chatbot
4. The chatbot will show a warning if Ollama is not running

> **Note:** If Ollama is not available, the AI Quiz will use built-in demo questions so the app still works.

---

## 📋 REQUIREMENTS

See `requirements.txt` for full list. Key packages:
- Django 4.2.7
- Pillow (image handling)
- scikit-learn (data mining)
- pandas, numpy (analytics)

---

## 🎓 PROJECT PRESENTATION FLOW

1. **Login** → Show role-based auth (teacher1 + student1)
2. **Teacher Dashboard** → Create course, share code
3. **Student Dashboard** → Enroll with code, view course
4. **Assignment** → Student submits → Teacher grades
5. **AI Chatbot** → Ask "Explain machine learning" (Ollama)
6. **AI Quiz** → Generate quiz on "Python" topic
7. **Attention Tracker** → Webcam + face mesh demo
8. **Analytics** → Charts, weak topics, recommendations
9. **Dark Mode** → Toggle for wow factor

---

*Built with ❤️ for Final Year Project*
