from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/',       admin.site.urls),
    path('accounts/',    include('accounts.urls')),
    path('courses/',     include('courses.urls')),
    path('assignments/', include('assignments.urls')),
    path('ai/',          include('ai_tools.urls')),
    path('analytics/',   include('analytics.urls')),
    path('',             include('dashboard.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) \
  + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
