from django.db import models
from django.conf import settings
import random, string

def generate_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

class Course(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    course_code = models.CharField(max_length=10, unique=True, default=generate_code)
    teacher = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='taught_courses', limit_choices_to={'is_teacher': True})
    students = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='enrolled_courses',
                                      blank=True, limit_choices_to={'is_student': True})
    created_at = models.DateTimeField(auto_now_add=True)
    thumbnail = models.ImageField(upload_to='course_thumbnails/', blank=True, null=True)
    color = models.CharField(max_length=7, default='#6c63ff')

    def __str__(self):
        return self.title

    def student_count(self):
        return self.students.count()
