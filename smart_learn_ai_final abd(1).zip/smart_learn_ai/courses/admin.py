from django.contrib import admin
from .models import Course

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['title', 'teacher', 'course_code', 'student_count', 'created_at']
    list_filter = ['teacher']
