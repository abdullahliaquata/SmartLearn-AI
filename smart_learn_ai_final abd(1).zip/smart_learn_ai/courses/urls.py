from django.urls import path
from . import views

app_name = 'courses'

urlpatterns = [
    path('create/',          views.CreateCourseView.as_view(), name='create'),
    path('<int:pk>/',        views.course_detail,              name='detail'),
    path('<int:pk>/edit/',   views.EditCourseView.as_view(),   name='edit'),
    path('<int:pk>/delete/', views.delete_course,              name='delete'),
    path('enroll/',          views.EnrollView.as_view(),       name='enroll'),
]
