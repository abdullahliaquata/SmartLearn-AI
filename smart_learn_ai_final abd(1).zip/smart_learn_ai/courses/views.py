from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.utils.decorators import method_decorator
from django.views import View
from .models import Course
from .forms import CourseForm, EnrollForm

is_teacher = lambda u: u.is_teacher
is_student  = lambda u: u.is_student


@method_decorator([login_required, user_passes_test(is_teacher)], name='dispatch')
class CreateCourseView(View):
    def get(self, request):
        return render(request, 'courses/create_course.html', {'form': CourseForm()})

    def post(self, request):
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.teacher = request.user
            course.save()
            messages.success(request, f'✅ Course "{course.title}" created! Code: {course.course_code}')
            return redirect('dashboard:teacher_home')
        return render(request, 'courses/create_course.html', {'form': form})


@method_decorator([login_required, user_passes_test(is_teacher)], name='dispatch')
class EditCourseView(View):
    def get(self, request, pk):
        course = get_object_or_404(Course, pk=pk, teacher=request.user)
        form = CourseForm(instance=course)
        return render(request, 'courses/edit_course.html', {'form': form, 'course': course})

    def post(self, request, pk):
        course = get_object_or_404(Course, pk=pk, teacher=request.user)
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            form.save()
            messages.success(request, f'✅ Course "{course.title}" updated!')
            return redirect('dashboard:teacher_home')
        return render(request, 'courses/edit_course.html', {'form': form, 'course': course})


@login_required
def course_detail(request, pk):
    course = get_object_or_404(Course, pk=pk)
    from assignments.models import Assignment
    if request.user.is_teacher:
        assignments = Assignment.objects.filter(course=course).order_by('-submitted_at')
        return render(request, 'courses/course_detail_teacher.html',
                      {'course': course, 'assignments': assignments})
    else:
        my_assignment = Assignment.objects.filter(course=course, submitted_by=request.user).first()
        return render(request, 'courses/course_detail_student.html',
                      {'course': course, 'my_assignment': my_assignment})


@method_decorator([login_required, user_passes_test(is_student)], name='dispatch')
class EnrollView(View):
    def get(self, request):
        return render(request, 'courses/enroll.html', {'form': EnrollForm()})

    def post(self, request):
        form = EnrollForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['course_code'].upper().strip()
            try:
                course = Course.objects.get(course_code=code)
                if request.user in course.students.all():
                    messages.info(request, 'ℹ️ You are already enrolled in this course!')
                else:
                    course.students.add(request.user)
                    messages.success(request, f'✅ Enrolled in "{course.title}" successfully!')
                return redirect('dashboard:student_home')
            except Course.DoesNotExist:
                messages.error(request, '❌ Invalid course code. Please check and try again.')
        return render(request, 'courses/enroll.html', {'form': form})


@login_required
@user_passes_test(is_teacher)
def delete_course(request, pk):
    course = get_object_or_404(Course, pk=pk, teacher=request.user)
    title = course.title
    course.delete()
    messages.success(request, f'✅ Course "{title}" deleted successfully.')
    return redirect('dashboard:teacher_home')
